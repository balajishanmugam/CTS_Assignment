export class CSVRecord {
    public firstName: any;
    public surName: any;
    public issueCount: any;
    public dateOfBirth: any;
  }
