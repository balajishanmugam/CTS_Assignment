import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { FormsModule }   from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavHeaderComponent } from './common/nav-header/nav-header.component';
import { FooterComponent } from './common/footer/footer.component';
import { CsvToTableComponent } from './csv-to-table/csv-to-table.component';
import { FilterPipe } from './pipe/filter/filter.pipe';

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    CsvToTableComponent,
    FilterPipe,
    NavHeaderComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  bootstrap: [AppComponent]
})
export class AppModule { }
