import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CsvToTableComponent } from './csv-to-table.component';
import { FormsModule } from '@angular/forms';
import { FilterPipe } from '../pipe/filter/filter.pipe';

describe('CsvToTableComponent', () => {
  let component: CsvToTableComponent;
  let fixture: ComponentFixture<CsvToTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule ],
      declarations: [ CsvToTableComponent, FilterPipe ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CsvToTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('File selection label should be Select CSV File', ()=> {
    fixture = TestBed.createComponent(CsvToTableComponent);
    component = fixture.componentInstance;
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('.upload-file-label').textContent).toContain('Select CSV File');
  });

  it('File extension ends with CSV', () => {
    fixture = TestBed.createComponent(CsvToTableComponent);
    component = fixture.componentInstance;
    let fileName = {name: 'issues.csv'};
    expect(component.isCSVFile(fileName)).toBeTruthy();
  });

  it('Header array length should be 4', () => {
    fixture = TestBed.createComponent(CsvToTableComponent);
    component = fixture.componentInstance;
    let headerArr = ['"First name","Sur name","Issue count","Date of birth"', 
    '"Theo","Jansen",5,"1978-01-02T00:00:00"', 
    '"Fiona","de Vries",7,"1950-11-12T00:00:00"', 
    '"Petra","Boersma",1,"2001-04-20T00:00:00"'];
    expect(component.getHeaderArray(headerArr).length).toBe(4);
  });

  // it()
});
