import { Component, OnInit, ViewChild } from '@angular/core';
import swal from 'sweetalert2';
import { CSVRecord } from '../interface/csvrecord';

@Component({
  selector: 'app-csv-to-table',
  templateUrl: './csv-to-table.component.html',
  styleUrls: ['./csv-to-table.component.scss']
})

export class CsvToTableComponent implements OnInit {

 public csvRecords: any[] = [];
 uploadedFileName = '';
 filterCount = '';
  @ViewChild('fileImportInput', { static: false }) fileImportInput: any;

  constructor() { }

  ngOnInit() {
  }

  /** PROCESS FILE SELECTION AND RENDER THE DATA FROM CSV FILE IN TABLE*/
  fileChangeListener($event: any): void {
    let files = $event.srcElement.files;
    this.uploadedFileName = files[0].name;
    if (this.isCSVFile(files[0])) {
      let input = $event.target;
      let reader = new FileReader();
      reader.readAsText(input.files[0]);
      reader.onload = () => {
        let csvData = reader.result;
        let csvRecordsArray = (<string>csvData).split(/\r\n|\n/);
        let headersRow = this.getHeaderArray(csvRecordsArray);
        this.csvRecords = this.getDataRecordsFromCSVFile(csvRecordsArray, headersRow.length);
      };
      reader.onerror = function () {
        swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Unable to read ' + input.files[0],
        })
      };
    } else {
      swal.fire("Please import valid .csv file.");
      this.clearFile();
    }
  }

  /** GET DATA FROM CSV FILE */
  getDataRecordsFromCSVFile(csvRecordsArray: any, headerLength: any) {
    let dataArr = [];
    for (let i = 1; i < csvRecordsArray.length; i++) {
      let data = (<string>csvRecordsArray[i]).split(',');
      if (data.length == headerLength) {
        let csvRecord: CSVRecord = new CSVRecord();
        csvRecord.firstName = data[0].replace(/['"]+/g, '').trim();
        csvRecord.surName = data[1].replace(/['"]+/g, '').trim();
        csvRecord.issueCount = data[2].trim();
        csvRecord.dateOfBirth = data[3].replace(/['"]+/g, '').trim();
        dataArr.push(csvRecord);
      }
    }
    return dataArr;
  }
  /** CHECK IF FILE IS A VALID CSV FILE */
  isCSVFile(file: any) {
    return file.name.endsWith(".csv");
  }
  /** GET CSV FILE HEADER COLUMNS */
  getHeaderArray(csvRecordsArr: any) {
    let headers = (<string>csvRecordsArr[0]).split(',');
    let headerArray = [];
    for (let j = 0; j < headers.length; j++) {
      headerArray.push(headers[j]);
    }
    return headerArray;
  }
  /** RESET OR CLEAR THE CSV FILE WHICH ALREADY SELECTED  */
  clearFile() {
    this.fileImportInput.nativeElement.value = "";
    this.uploadedFileName = '';
    this.csvRecords = [];
  }

}
