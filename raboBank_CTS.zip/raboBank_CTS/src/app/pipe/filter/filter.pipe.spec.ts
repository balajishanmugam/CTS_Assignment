import { FilterPipe } from './filter.pipe';

describe('FilterPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterPipe();
    expect(pipe).toBeTruthy();
  });

  it('Should filter object based issue count number', () => {
    const pipe = new FilterPipe();
    let value = [{firstName: "Theo", surName: "Jansen", issueCount: "5", dateOfBirth: "1978-01-02T00:00:00"},
    {firstName: "Fiona", surName: "de Vries", issueCount: "7", dateOfBirth: "1950-11-12T00:00:00"},
    {firstName: "Petra", surName: "Boersma", issueCount: "1", dateOfBirth: "2001-04-20T00:00:00"}];
    let filterString = '7';
    let propName = 'issueCount';
    let result = [{firstName: "Fiona", surName: "de Vries", issueCount: "7", dateOfBirth: "1950-11-12T00:00:00"}];
    expect(pipe.transform(value, filterString, propName)).toEqual(result);
  })
});
