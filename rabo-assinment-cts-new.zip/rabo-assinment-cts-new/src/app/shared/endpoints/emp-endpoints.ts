export const empEndpoints = {
    'login' : 'https://reqres.in/api/login',
    'getEmployee': 'http://dummy.restapiexample.com/api/v1/employees',
    'createEmployee': 'http://dummy.restapiexample.com/api/v1/create',
    'updateEmployee': 'http://dummy.restapiexample.com/api/v1/update',
    'deleteEmployee': 'http://dummy.restapiexample.com/api/v1/delete',
  };