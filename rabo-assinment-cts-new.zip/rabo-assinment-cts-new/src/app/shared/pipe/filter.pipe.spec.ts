import { FilterPipe } from './filter.pipe';

describe('FilterPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterPipe();
    expect(pipe).toBeTruthy();
  });
});

it('Should filter object based on entered empolyee name', () => {
  const pipe = new FilterPipe();
  let value = [{id: "1", employee_name: "Tiger Nixon", employee_salary: "320800", employee_age: "61", profile_image: ""},
  {id: "2", employee_name: "Garrett Winters", employee_salary: "170750", employee_age: "63", profile_image: ""},
  {id: "3", employee_name: "Ashton Cox", employee_salary: "86000", employee_age: "66", profile_image: ""},
  {id: "4", employee_name: "Cedric Kelly", employee_salary: "433060", employee_age: "22", profile_image: ""}];
  let filterString = 'Ashton Cox';
  let propName = 'employee_name';
  let result = [{id: "3", employee_name: "Ashton Cox", employee_salary: "86000", employee_age: "66", profile_image: ""}];
  expect(pipe.transform(value, filterString, propName)).toEqual(result);
})
