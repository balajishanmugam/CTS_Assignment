import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { empEndpoints } from '../shared/endpoints/emp-endpoints';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor( private http: HttpClient) { }
  private getHeaders() {
    return new HttpHeaders({ 'Content-Type': 'application/json' });
  }

  createEmp(data): Observable<any> {
    return this.http.post(empEndpoints.createEmployee, data, { headers: this.getHeaders() } );
  }

  getEmp(): Observable<any> {
    return this.http.get(empEndpoints.getEmployee, { headers: this.getHeaders() });
  }

}
