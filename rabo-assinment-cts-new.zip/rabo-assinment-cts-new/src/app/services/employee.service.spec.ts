import { TestBed, getTestBed, inject  } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import {HttpClientModule, HttpClient} from '@angular/common/http';
import { EmployeeService } from './employee.service';


const dummyEmployeeListResponse = [{id: "1", employee_name: "Tiger Nixon", employee_salary: "320800", employee_age: "61", profile_image: ""},
{id: "2", employee_name: "Garrett Winters", employee_salary: "170750", employee_age: "63", profile_image: ""},
{id: "3", employee_name: "Ashton Cox", employee_salary: "86000", employee_age: "66", profile_image: ""},
{id: "4", employee_name: "Cedric Kelly", employee_salary: "433060", employee_age: "22", profile_image: ""}];

describe('EmployeeService', () => {
  let httpMock: HttpTestingController;
  let injector: TestBed;
  let service: EmployeeService;
  let httpClient: HttpClient;

  beforeEach(() => {
  TestBed.configureTestingModule({
    imports: [HttpClientModule, HttpClientTestingModule],
    providers: [EmployeeService],
  });
  injector = getTestBed();
  service = injector.get(EmployeeService);
  httpMock = injector.get(HttpTestingController);
});

afterEach(() => {
  httpMock.verify();
}); 

  it('should be created', () => {
    const service: EmployeeService = TestBed.get(EmployeeService);
    expect(service).toBeTruthy();
  });

  it('getEmp() should return data', () => { 
    service.getEmp().subscribe((res) => {
      expect(res).toEqual(dummyEmployeeListResponse);
    });

    const req = httpMock.expectOne('http://dummy.restapiexample.com/api/v1/employees');
    expect(req.request.method).toBe('GET');
    req.flush(dummyEmployeeListResponse);
  });

  it('createEmp() should POST and return data', () => {
    const postData = {"name":"test","salary":"123","age":"23"};
    const resultData = {
      "status": "success",
      "data": {
          "name": "test",
          "salary": "123",
          "age": "23",
          "id": 25
      }
  };
    service.createEmp(postData).subscribe((res) => {
      expect(res).toEqual(resultData);
    });

    const req = httpMock.expectOne('http://dummy.restapiexample.com/api/v1/create');
    expect(req.request.method).toBe('POST');
    req.flush(resultData);
  });

});
