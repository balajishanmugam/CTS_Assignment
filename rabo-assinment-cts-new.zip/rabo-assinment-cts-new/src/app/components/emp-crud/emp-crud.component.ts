import { Component, ViewChild, OnInit, OnDestroy } from '@angular/core';
import { EmployeeService } from '../../services/employee.service';
import { FormBuilder, FormArray, Validators, FormGroup } from '@angular/forms';
import Swal from 'sweetalert2';
import { Employee } from 'src/app/interface/employee';

@Component({
  selector: 'app-emp-crud',
  templateUrl: './emp-crud.component.html',
  styleUrls: ['./emp-crud.component.scss']
})
export class EmpCrudComponent implements OnInit, OnDestroy {

  getEmployees: any;
  employees: any = [];
  loader = false;
  closeResult: string;
  submitted = false;
  filterName = [];
  showForm: boolean = false;
  

  constructor(private empService: EmployeeService, private fb: FormBuilder) { }
  addEmpForm :FormGroup = this.fb.group({
    name: ['', [Validators.required, Validators.minLength(3), Validators.pattern('^[a-zA-Z ]*$') ]],
    salary: ['', [ Validators.required, Validators.minLength(2), Validators.pattern('^[0-9]*$')]],
    age: ['', [Validators.required, Validators.minLength(2), Validators.pattern('^[0-9]*$')]],
});
  


  ngOnInit() {
  this.getEmpl();
  }

  get f() { return this.addEmpForm.controls; }
  
/** Get employees data from service  */
  getEmpl() {
    this.loader = true;
    this.getEmployees = this.empService.getEmp().subscribe(resp => {
      this.loader = false;
      this.employees  = resp.data;
    });
  }

  /** Post new empolyee data through service */
  addEmp() {
    this.submitted = true;
    const data = this.addEmpForm.value;
    if (!this.addEmpForm.valid){
      console.log('Invalid Form');
    } else {
      this.loader = true;
      this.empService.createEmp(data).subscribe(resp => {
        if(resp.status === 'success') {
          Swal.fire({
            icon: 'success',
            title: 'Yay...'+ ' ' + resp.status+'!',
            text: 'Employee successfully added',
          })
          this.getEmpl();
          this.submitted = false;
          this.showForm = false;
          this.addEmpForm.reset();
        } else {
          Swal.fire({
            icon: 'error',
            title: 'Oops...'+ ' ' + resp.status+'!',
            text: 'Something went wrong',
          })
        }
       
      });
    }
  }
  showEmpForm() {
    this.showForm = !this.showForm;
  }



  ngOnDestroy() {
    this.getEmployees.unsubscribe();
  }

}
