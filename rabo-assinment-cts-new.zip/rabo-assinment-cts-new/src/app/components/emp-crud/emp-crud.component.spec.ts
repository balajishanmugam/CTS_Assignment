import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule }   from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { EmpCrudComponent } from './emp-crud.component';
import { LoaderComponent } from '../loader/loader.component';
import { FilterPipe } from 'src/app/shared/pipe/filter.pipe';
import { EmployeeService } from 'src/app/services/employee.service';

describe('EmpCrudComponent', () => {
  let component: EmpCrudComponent;
  let fixture: ComponentFixture<EmpCrudComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmpCrudComponent, LoaderComponent, FilterPipe ],
      imports: [FormsModule, ReactiveFormsModule, HttpClientModule],
      providers: [EmployeeService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmpCrudComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('form invalid when empty', () => {
    expect(component.addEmpForm.valid).toBeFalsy();
});

it('Name  field validity', () => {
  let errors = {};
  let name = component.addEmpForm.controls['name'];
  expect(name.valid).toBeFalsy();

  // name field is required
  errors = name.errors || {};
  expect(errors['required']).toBeTruthy();

  // Set name to something
  name.setValue("1234");
  errors = name.errors || {};
  expect(errors['required']).toBeFalsy();
  expect(errors['pattern']).toBeTruthy();

  // Set email to something correct
  name.setValue("Balaji K S");
  errors = name.errors || {};
  expect(errors['required']).toBeFalsy();
  expect(errors['pattern']).toBeFalsy();
});

it('Name field validity', () => {
  let errors = {};
  let salary = component.addEmpForm.controls['salary'];
  expect(salary.valid).toBeFalsy();

  // name field is required
  errors = salary.errors || {};
  expect(errors['required']).toBeTruthy();

  // Set name to something
  salary.setValue("abcd");
  errors = salary.errors || {};
  expect(errors['required']).toBeFalsy();
  expect(errors['pattern']).toBeTruthy();

  // Set name to something correct
  salary.setValue("1500000");
  errors = salary.errors || {};
  expect(errors['required']).toBeFalsy();
  expect(errors['pattern']).toBeFalsy();
});

it('Salary field validity', () => {
  let errors = {};
  let salary = component.addEmpForm.controls['salary'];
  expect(salary.valid).toBeFalsy();

  // name field is required
  errors = salary.errors || {};
  expect(errors['required']).toBeTruthy();

  // Set salary to something
  salary.setValue("abcd");
  errors = salary.errors || {};
  expect(errors['required']).toBeFalsy();
  expect(errors['pattern']).toBeTruthy();

  // Set salary to something correct
  salary.setValue("1500000");
  errors = salary.errors || {};
  expect(errors['required']).toBeFalsy();
  expect(errors['pattern']).toBeFalsy();
});

it('Age field validity', () => {
  let errors = {};
  let age = component.addEmpForm.controls['age'];
  expect(age.valid).toBeFalsy();

  // age field is required
  errors = age.errors || {};
  expect(errors['required']).toBeTruthy();

  // Set age to something
  age.setValue("abcd");
  errors = age.errors || {};
  expect(errors['required']).toBeFalsy();
  expect(errors['pattern']).toBeTruthy();

  // Set age to something correct
  age.setValue("31");
  errors = age.errors || {};
  expect(errors['required']).toBeFalsy();
  expect(errors['pattern']).toBeFalsy();
});

it('submitting a addEmpform to equal valid object', () => {
  expect(component.addEmpForm.valid).toBeFalsy();
  component.addEmpForm.controls['name'].setValue("Balaji");
  component.addEmpForm.controls['salary'].setValue("150000");
  component.addEmpForm.controls['age'].setValue("31");
  expect(component.addEmpForm.valid).toBeTruthy();

  component.addEmp();
  const finalObj = { name: 'Balaji', salary: '150000', age: '31' };
  expect(component.addEmpForm.value).toEqual(finalObj);
});

  it('should render title in a h5 tag', () => {
    const fixture = TestBed.createComponent(EmpCrudComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('h5').textContent).toContain('Manage Employees');
  });
  
  it('should "employees" length is zero on load ', () => {
    expect(component.employees.length).toEqual(0);
  });

  it("should call getEmpl() and return type of response", async(() => {
    component.getEmpl();
    expect(typeof(component.employees)).toBe('object');
  }));

});
