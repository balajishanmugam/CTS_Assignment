export class Employee {
    public id: string;
    public employee_name: string;
    public employee_salary: string;
    public employee_age: string;
    public profile_image: string;
  }
